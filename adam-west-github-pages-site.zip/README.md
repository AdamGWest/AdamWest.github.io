# Adam West — GitHub Pages Site

## Publish on GitHub Pages

1. Create a new GitHub repository named `adam-west.github.io` if your GitHub username is `adam-west`.
   - If your username is different, use `<your-username>.github.io` for a personal site, or any repository name for a project site.
2. Upload `index.html` and `style.css`.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then Save.
6. Wait a few minutes and open the Pages URL GitHub gives you.

## Before publishing

- Replace `YOUR_EMAIL_HERE` in `index.html` with your real email.
- Replace the `YOUR PHOTO` placeholder with your preferred hero photo.
- Optional: add a `resume.pdf` to the repository and a resume button later.

## Social links included

- Instagram: @AW_Rootbeer
- TikTok: @TheAdamWest
- LinkedIn: Adam West
